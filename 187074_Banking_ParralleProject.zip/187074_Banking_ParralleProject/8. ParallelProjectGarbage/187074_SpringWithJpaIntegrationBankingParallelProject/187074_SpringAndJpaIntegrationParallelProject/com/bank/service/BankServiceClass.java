package com.bank.service;

import com.bank.dao.DaoClass;
import com.bank.dao.DaoInterface;
import com.bank.exception.AccountNotFoundException;
import com.bank.exception.InsufficientFundException;
import com.bank.user.bean.TransactionBean;
import com.bank.user.bean.UserBean;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//this class use to create random account Id.
class RandomAccountIdGenerator {
	static Random randNumber = new Random();

	static String generateRandom(String userName, long mobileNumber) {
		String s1 = Long.toString(mobileNumber);
		String name = userName.substring(0, 2);
		int n = randNumber.nextInt(100);
		String pass = s1.substring(4, 8);
		String accountId = name.toUpperCase() + pass + n;
		return accountId;
	}

}

@Service("BankService")
public class BankServiceClass implements BankServiceInterface {

	@Autowired
	private DaoInterface daoservice;
	
	Scanner sc = new Scanner(System.in);

	@Override
	public String userAccountCreate(String accountPassword, String userName, long mobileNumber) {
		
		UserBean userbean = new UserBean();
		
		userbean.setName(userName);

		userbean.setAccountPassword(accountPassword);
		userbean.setMobileNumber(mobileNumber);

		int i = daoservice.userAccountCreate(userbean);
		if (i == 1) {
			return "Your Account is created with account ID " + userbean.getAccountId();
		} else {
			System.out.println("Something Went Wrong");
			return "There is Some Problem in Account Creation";
		}
	}

	@Override
	public String showBalance(int accountId) {
		String s = daoservice.showBalance(accountId);
		return s;
	}

	@Override
	public String deposit(int accountId, int amount) {
		// TODO Auto-generated method stub
		String s = daoservice.Deposit(accountId, amount);
		return s;
	}

	@Override
	public String withDraw(int accountId, int amount) {
		String s = daoservice.withDraw(accountId, amount);
		return s;
	}

	@Override
	public String fundTransfer(int sourceAccountId, int destinationAccountId, int amount) {
		String s = daoservice.fundTransfer(sourceAccountId, destinationAccountId, amount);
		return s;
	}

	@Override
	public int Login(int accountId, String accountPassword) {
		int i = daoservice.Login(accountId, accountPassword);
		if (i == 1) {
			return 1;
		} else {
			return 0;
		}
	}

	@Override
	public String printTransactions(int accountId) {
		// TODO Auto-generated method stub
		HashMap hm = daoservice.printTransactions(accountId);
		
		Set s = hm.entrySet();

		Iterator i = s.iterator();
		String trans = "";
		

		return trans;

		
	}
//  method for Validtion of the  Name
	
	
	public String nameCheck(String name) {

		while (true) {

			try {
				if (name.matches("[A-Z a-z]{3,10}")) {
					return name;
				} else {

					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("------------ Error----------------");
				System.out.println("Please Enter Valid Name (names >2 and numbers are not allowed) ");
				System.out.println("Enter again:[Enter exit for dashboard]");
				name = sc.nextLine();
				if (name.equals("exit")) {
					return "exit";
				}
			}
		}
	}

	// Password Validation
	
	
	public String passwordCheck(String password) {
		while (true) {
			try {
				if (password.matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{4,16}$")) {
					return password;

				} else {
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("Invalid Password..Password should start with Capital letters and must contains one digit )");
				System.out.println("Enter again:[Enter exit for dashboard]");
				password = sc.nextLine();
				if (password.equals("exit")) {
					return "exit";
				}
			}

		}
	}

	// Mobile Number Validation
	
	
	public String mobileNumberCheck(String mobileNumber) {
		while (true) {
			try {
				if (mobileNumber.matches("[6-9][0-9]{9}")) {
					return mobileNumber;

				} else {
					throw new Exception();
				}
			} catch (Exception ex) {
				System.out.println("Enter Valid Mobile number .. ie exact   10 digit only)");
				System.out.println("Enter again:");
				mobileNumber = sc.nextLine();
				if (mobileNumber.equals("exit")) {
					return "exit";
				}
			}

		}
	}

	// Amount Validation
	
	
	public String amountLimitCheck(String amount) {
		while (true) {
			try {
				if (amount.length() > 6 || amount.equals(0)) {
					throw new Exception();
				} else {
					return amount;
				}
			} catch (Exception ex) {
				System.out.println("Enter valid Amount ...Amount Should be (less than 999999)");
				System.out.println("Enter Again");
				amount = sc.nextLine();
				if (amount.equals("exit")) {
					return "exit";
				}
			}
		}
	}

	// Validation for ValidAccountId
	
	
	@Override
	public String validAccountId(String accountId) {
		if (daoservice.validAccountId(Integer.parseInt(accountId))) {
			return accountId;
		} else {
			throw new AccountNotFoundException("Your Account Number is not valid..");
		}

	}

	// Validation for Balance Check
	
	
	@Override
	public String checkBalance(String accountId, String amount) {
		if (daoservice.checkBalance(Integer.parseInt(accountId), Integer.parseInt(amount))) { 
			return amount;
		} else {
			throw new InsufficientFundException("Insufficient Amount in Your Account ");
		}

	}

}
