package com.capg.dao;

import com.capg.entities.AuthorDetails;

public interface AuthorDAO {
	
	public void addAuthor(AuthorDetails a);
	public void removeAuthor(AuthorDetails a);
	public void updateAuthor(AuthorDetails a);
	public AuthorDetails findAuthor(int aid);

}
